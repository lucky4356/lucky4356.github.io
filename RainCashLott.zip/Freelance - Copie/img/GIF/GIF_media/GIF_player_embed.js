var oeTags = '<img src="GIF_media/GIF.gif" width="980" height="200" alt=""/>';         
document.write( oeTags );
